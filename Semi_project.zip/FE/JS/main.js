<script>
document.getElementById("navi").onclick =function(){
  
}


</script>